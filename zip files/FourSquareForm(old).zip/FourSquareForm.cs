﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace FourSquare
{
    public partial class frmFourSquareWorksheet : Form
    {
        //private Loan carLoan { get; set; }
        private double compensatingBalance { get; set; }
        private double loanPresentValue { get; set; }
        private double tradeIn;
        private double downPayment;
        private double salePrice;
        private double monthlyPayment;
        private double interestRate;
        private double numberPayments;
        private DueDate whenDue { get; set; }

        public frmFourSquareWorksheet()
        {
            InitializeComponent();
            btnInterest.Enabled = false;
            cbxDueAtMonthEnd.Checked = false;
            refreshControls();
        }

        private void refreshControls()
        {
            if (tradeIn != 0)
            {
                txtTradeIn.Text = tradeIn.ToString();
            }
            else
            {
                txtTradeIn.Text = "";
            }

            if (compensatingBalance != 0)
            {
                txtCompensatingBalance.Text = compensatingBalance.ToString();
            }
            else
            {
                txtCompensatingBalance.Text = "";
            }

            if (loanPresentValue != 0)
            {
                txtPresentValue.Text = loanPresentValue.ToString();
            }
            else
            {
                txtPresentValue.Text = "";
            }

            btnSalePrice.Enabled = (
                monthlyPayment > 0
                && interestRate > 0
                && numberPayments > 0);

            btnInterest.Enabled = (
                loanPresentValue > 0
                && salePrice > 0
                && monthlyPayment > 0
                && numberPayments > 0);

            btnPayment.Enabled = (
                loanPresentValue > 0
                && salePrice > 0
                && interestRate > 0
                && numberPayments > 0);

            btnMonths.Enabled = (
               loanPresentValue > 0
               && salePrice > 0
               && monthlyPayment > 0
               && interestRate > 0);

            if (cbxDueAtMonthEnd.Checked)
            {
                whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                whenDue = DueDate.BegOfPeriod;
            }

            Refresh();
        }

        private void txtTradeIn_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtTradeIn.Text, out tradeIn);
        }

        private void txtDownPayment_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtDownPayment.Text, out downPayment);
        }

        private void txtNumberPayments_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtNumberPayments.Text, out numberPayments);
            refreshControls();
        }

        private void txtSalePrice_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtSalePrice.Text, out salePrice);
        }

        private void txtMonthlyPayment_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtMonthlyPayment.Text, out monthlyPayment);
            refreshControls();
        }

        private void txtInterestRate_TextChanged(object sender, EventArgs e)
        {
            validateTextbox(txtInterestRate.Text, out interestRate);
            refreshControls();
        }

        private void btnSalePrice_Click(object sender, EventArgs e)
        {
            calculateSalePrice();
            txtPresentValue.Text = loanPresentValue.ToString();
            txtSalePrice.Text = salePrice.ToString();
            refreshControls();
        }

        private void btnInterest_Click(object sender, EventArgs e)
        {
            if (cbxDueAtMonthEnd.Checked)
            {
                whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                whenDue = DueDate.BegOfPeriod;
            }

            calculateInterestRate();
            txtInterestRate.Text = interestRate.ToString();
            refreshControls();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            calculateMonthlyPayment();

            txtMonthlyPayment.Text = monthlyPayment.ToString();
            refreshControls();
        }

        private void cbxDueAtMonthEnd_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxDueAtMonthEnd.Checked)
            {
                whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                whenDue = DueDate.BegOfPeriod;
            }
            
            if (btnInterest.Enabled && numberPayments > 0)
            {
                calculateInterestRate();
                txtInterestRate.Text = interestRate.ToString();
            }
            refreshControls();
        }

        private void validateTextbox(string textToValidate, out double result)
        {
            if (!double.TryParse(textToValidate, out result)
                && txtTradeIn.Text.Length > 0)
            {
                //MessageBox.Show("Only numbers and '.' are allowed.");
                result = 0;
            }
            else
            {
                recalculate();
                refreshControls();
            }
        }

        private void clearForm()
        {
            txtCompensatingBalance.Text = "";
            txtDownPayment.Text = "";
            txtInterestRate.Text = "";
            txtMonthlyPayment.Text = "";
            txtNumberPayments.Text = "";
            txtPresentValue.Text = "";
            txtSalePrice.Text = "";
            txtTradeIn.Text = "";
            cbxDueAtMonthEnd.Checked = false;
        }

        private void btnMonths_Click(object sender, EventArgs e)
        {
            calculateNumberPayments();

            txtNumberPayments.Text = numberPayments.ToString();
            refreshControls();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearValues();
            clearForm();
        }

        private void clearValues()
        {
            compensatingBalance = 0;
            loanPresentValue = 0;
            tradeIn = 0;
            downPayment = 0;
            salePrice = 0;
            monthlyPayment = 0;
            interestRate = 0;
            numberPayments = 0;
        }

        private void calculateAmountFinanced()
        {
            compensatingBalance = tradeIn + downPayment;
            loanPresentValue = salePrice - compensatingBalance;
        }

        private void calculateSalePrice()
        {
            loanPresentValue
                = Financial.PV(interestRate / 1200, numberPayments,
                    -monthlyPayment, 0, whenDue);

            compensatingBalance = Math.Round(compensatingBalance, 2);
            loanPresentValue = Math.Round(loanPresentValue, 2);
            tradeIn = Math.Round(tradeIn, 2);
            downPayment = Math.Round(downPayment, 2);

            salePrice = loanPresentValue + compensatingBalance;
        }

        private void calculateInterestRate()
        {
            interestRate
                = Math.Abs(Financial.Rate(numberPayments, -monthlyPayment,
                    loanPresentValue, 0, whenDue, 0.1) * 1200);

            interestRate = Math.Round(interestRate, 6);
        }

        private void calculateMonthlyPayment()
        {
            monthlyPayment
                = Math.Abs(Financial.Pmt(interestRate / 1200, numberPayments,
                    loanPresentValue, 0, whenDue));

            monthlyPayment = Math.Round(monthlyPayment, 2);
        }

        private void calculateNumberPayments()
        {
            numberPayments
                = Financial.NPer(interestRate / 1200, -monthlyPayment,
                    loanPresentValue, 0, whenDue);

            numberPayments = Math.Round(numberPayments, 0);
        }

        private void roundValues()
        {
            compensatingBalance = Math.Round(compensatingBalance, 2);
            loanPresentValue = Math.Round(loanPresentValue, 2);
            tradeIn = Math.Round(tradeIn, 2);
            downPayment = Math.Round(downPayment, 2);
            salePrice = Math.Round(salePrice, 2);
            monthlyPayment = Math.Round(monthlyPayment, 2);
            interestRate = Math.Round(interestRate, 6);
            numberPayments = Math.Round(numberPayments, 0);
        }

        private void recalculate()
        {
            calculateAmountFinanced();
            roundValues();
        }
    }
}
