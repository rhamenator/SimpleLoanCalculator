﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic;


namespace FourSquare
{
    public class Loan
    { 
        public static double compensatingBalance { get; set; }
        public static double loanPresentValue { get; set; }
        public static double tradeIn { get; set; }
        public static double downPayment { get; set; }
        public static double salePrice { get; set; }
        public static double monthlyPayment { get; set; }
        public static double interestRate { get; set; }
        public static double numberPayments { get; set; }
        public static DueDate whenDue { get; set; }

        public static void clearValues()
        {
            compensatingBalance = 0;
            loanPresentValue = 0;
            tradeIn = 0;
            downPayment = 0;
            salePrice = 0;
            monthlyPayment = 0;
            interestRate = 0;
            numberPayments = 0;
        }

        public static void calculateAmountFinanced()
        {
            compensatingBalance = tradeIn + downPayment;
            loanPresentValue = salePrice - compensatingBalance;
        }

        public static void calculateSalePrice()
        {
            loanPresentValue
                = Financial.PV(interestRate / 1200, numberPayments,
                    -monthlyPayment, 0, whenDue);

            compensatingBalance = Math.Round(compensatingBalance, 2);
            loanPresentValue = Math.Round(loanPresentValue, 2);
            tradeIn = Math.Round(tradeIn, 2);
            downPayment = Math.Round(downPayment, 2);

            salePrice = loanPresentValue + compensatingBalance;
        }

        public static void calculateInterestRate()
        {
            interestRate
                = Math.Abs(Financial.Rate(numberPayments, -monthlyPayment,
                    loanPresentValue, 0, whenDue, 0.1) * 1200);

            interestRate = Math.Round(interestRate, 6);
        }

        public static void calculateMonthlyPayment()
        {
            monthlyPayment
                = Math.Abs(Financial.Pmt(interestRate / 1200, numberPayments,
                    loanPresentValue, 0, whenDue));

            monthlyPayment = Math.Round(monthlyPayment, 2);
        }

        public static void calculateNumberPayments()
        {
            numberPayments
                = Financial.NPer(interestRate / 1200, -monthlyPayment,
                    loanPresentValue, 0, whenDue);

            numberPayments = Math.Round(numberPayments, 0);
        }

        public static void roundValues()
        {
            compensatingBalance = Math.Round(compensatingBalance, 2);
            loanPresentValue = Math.Round(loanPresentValue, 2);
            tradeIn = Math.Round(tradeIn, 2);
            downPayment = Math.Round(downPayment, 2);
            salePrice = Math.Round(salePrice, 2);
            monthlyPayment = Math.Round(monthlyPayment, 2);
            interestRate = Math.Round(interestRate, 6);
            numberPayments = Math.Round(numberPayments, 0);
        }
    }
}
