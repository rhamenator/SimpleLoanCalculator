﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace FourSquare
{
    public partial class frmLoanWorksheet : Form
    {
        private Loan carLoan { get; set; }

        public frmLoanWorksheet()
        {
            InitializeComponent();
            btnInterest.Enabled = false;
            cbxDueAtMonthEnd.Checked = false;
            refreshControls();
        }

        private void refreshControls()
        {
            if (Loan.tradeIn != 0)
            {
                txtTradeIn.Text = Loan.tradeIn.ToString();
            }
            else
            {
                txtTradeIn.Text = "";
            }

            if (Loan.compensatingBalance != 0)
            {
                txtCompensatingBalance.Text = Loan.compensatingBalance.ToString();
            }
            else
            {
                txtCompensatingBalance.Text = "";
            }

            if (Loan.loanPresentValue != 0)
            {
                txtPresentValue.Text = Loan.loanPresentValue.ToString();
            }
            else
            {
                txtPresentValue.Text = "";
            }

            btnSalePrice.Enabled = (
                Loan.monthlyPayment > 0
                && Loan.interestRate > 0
                && Loan.numberPayments > 0);

            btnInterest.Enabled = (
                Loan.loanPresentValue > 0
                && Loan.salePrice > 0
                && Loan.monthlyPayment > 0
                && Loan.numberPayments > 0);

            btnPayment.Enabled = (
                Loan.loanPresentValue > 0
                && Loan.salePrice > 0
                && Loan.interestRate > 0
                && Loan.numberPayments > 0);

            btnNumPayments.Enabled = (
               Loan.loanPresentValue > 0
               && Loan.salePrice > 0
               && Loan.monthlyPayment > 0
               && Loan.interestRate > 0);

            if (cbxDueAtMonthEnd.Checked)
            {
                Loan.whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                Loan.whenDue = DueDate.BegOfPeriod;
            }

            Refresh();
        }

        private void txtTradeIn_TextChanged(object sender, EventArgs e)
        {
            Loan.tradeIn = validateTextbox(txtTradeIn);
            Loan.calculateAmountFinanced();
            Loan.roundValues();
            refreshControls();
        }

        private void txtDownPayment_TextChanged(object sender, EventArgs e)
        {
            Loan.downPayment = validateTextbox(txtDownPayment);
            Loan.calculateAmountFinanced();
            Loan.roundValues();
            refreshControls();
        }

        private void txtNumberPayments_TextChanged(object sender, EventArgs e)
        {
            Loan.numberPayments = validateTextbox(txtNumberPayments);
            //Loan.recalculate();
            refreshControls();
        }

        private void txtSalePrice_TextChanged(object sender, EventArgs e)
        {
            Loan.salePrice = validateTextbox(txtSalePrice);
            Loan.calculateAmountFinanced();
            Loan.roundValues();
            refreshControls();
        }

        private void txtMonthlyPayment_TextChanged(object sender, EventArgs e)
        {
            Loan.monthlyPayment = validateTextbox(txtMonthlyPayment);
            Loan.roundValues();
            refreshControls();
        }

        private void txtInterestRate_TextChanged(object sender, EventArgs e)
        {
            Loan.interestRate = validateTextbox(txtInterestRate);
            Loan.roundValues();
            refreshControls();
        }

        private void btnSalePrice_Click(object sender, EventArgs e)
        {
            Loan.calculateSalePrice();
            Loan.roundValues();
            txtSalePrice.Text = Loan.salePrice.ToString();  // Change in this value triggers a recalculation of Loan.loanPresentValue
            txtPresentValue.Text = Loan.loanPresentValue.ToString();
            refreshControls();
        }

        private void btnInterest_Click(object sender, EventArgs e)
        {
            if (cbxDueAtMonthEnd.Checked)
            {
                Loan.whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                Loan.whenDue = DueDate.BegOfPeriod;
            }

            Loan.calculateInterestRate();
            txtInterestRate.Text = Loan.interestRate.ToString();
            refreshControls();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            Loan.calculateMonthlyPayment();

            txtMonthlyPayment.Text = Loan.monthlyPayment.ToString();
            refreshControls();
        }

        private void cbxDueAtMonthEnd_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxDueAtMonthEnd.Checked)
            {
                Loan.whenDue = DueDate.EndOfPeriod;
            }
            else
            {
                Loan.whenDue = DueDate.BegOfPeriod;
            }

            if (btnInterest.Enabled && Loan.numberPayments > 0)
            {
                Loan.calculateInterestRate();
                txtInterestRate.Text = Loan.interestRate.ToString();
            }
            refreshControls();
        }

        private static double validateTextbox(TextBox textBoxToValidate)
        {
            double result;

            if (!double.TryParse(textBoxToValidate.Text, out result))
            {
                if (!textBoxToValidate.Text.StartsWith("-"))
                {
                    result = 0;
                    textBoxToValidate.Text = "";
                }
            }
            return result;
        }

        private void clearForm()
        {
            txtCompensatingBalance.Text = "";
            txtDownPayment.Text = "";
            txtInterestRate.Text = "";
            txtMonthlyPayment.Text = "";
            txtNumberPayments.Text = "";
            txtPresentValue.Text = "";
            txtSalePrice.Text = "";
            txtTradeIn.Text = "";
            cbxDueAtMonthEnd.Checked = false;
        }

        private void btnNumPayments_Click(object sender, EventArgs e)
        {
            Loan.calculateNumberPayments();

            txtNumberPayments.Text = Loan.numberPayments.ToString();
            refreshControls();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Loan.clearValues();
            clearForm();
        }
    }
}
