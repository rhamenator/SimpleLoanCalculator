﻿namespace FourSquare
{
    partial class frmLoanWorksheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSalePrice = new System.Windows.Forms.Button();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.lblLoanPresentValue = new System.Windows.Forms.Label();
            this.txtPresentValue = new System.Windows.Forms.TextBox();
            this.cbxDueAtMonthEnd = new System.Windows.Forms.CheckBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDone = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblTradeIn = new System.Windows.Forms.Label();
            this.txtTradeIn = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSalePrice = new System.Windows.Forms.TextBox();
            this.lblSalePrice = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtDownPayment = new System.Windows.Forms.TextBox();
            this.lblDownPayment = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblMonthlyPayment = new System.Windows.Forms.Label();
            this.txtMonthlyPayment = new System.Windows.Forms.TextBox();
            this.btnPayment = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblCompensatingBalance = new System.Windows.Forms.Label();
            this.txtCompensatingBalance = new System.Windows.Forms.TextBox();
            this.btnInterest = new System.Windows.Forms.Button();
            this.btnNumPayments = new System.Windows.Forms.Button();
            this.lblNumPayments = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.txtNumberPayments = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSalePrice
            // 
            this.btnSalePrice.Location = new System.Drawing.Point(198, 16);
            this.btnSalePrice.Name = "btnSalePrice";
            this.btnSalePrice.Size = new System.Drawing.Size(66, 23);
            this.btnSalePrice.TabIndex = 0;
            this.btnSalePrice.Text = "Calculate";
            this.btnSalePrice.UseVisualStyleBackColor = true;
            this.btnSalePrice.Click += new System.EventHandler(this.btnSalePrice_Click);
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Location = new System.Drawing.Point(102, 45);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(92, 20);
            this.txtInterestRate.TabIndex = 3;
            this.txtInterestRate.TextChanged += new System.EventHandler(this.txtInterestRate_TextChanged);
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Location = new System.Drawing.Point(63, 49);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(37, 13);
            this.lblInterestRate.TabIndex = 2;
            this.lblInterestRate.Text = "APR%";
            // 
            // lblLoanPresentValue
            // 
            this.lblLoanPresentValue.AutoSize = true;
            this.lblLoanPresentValue.Location = new System.Drawing.Point(46, 45);
            this.lblLoanPresentValue.Name = "lblLoanPresentValue";
            this.lblLoanPresentValue.Size = new System.Drawing.Size(90, 13);
            this.lblLoanPresentValue.TabIndex = 2;
            this.lblLoanPresentValue.Text = "Amount Financed";
            // 
            // txtPresentValue
            // 
            this.txtPresentValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPresentValue.Location = new System.Drawing.Point(136, 45);
            this.txtPresentValue.Name = "txtPresentValue";
            this.txtPresentValue.ReadOnly = true;
            this.txtPresentValue.Size = new System.Drawing.Size(92, 13);
            this.txtPresentValue.TabIndex = 3;
            this.txtPresentValue.TabStop = false;
            // 
            // cbxDueAtMonthEnd
            // 
            this.cbxDueAtMonthEnd.AutoSize = true;
            this.cbxDueAtMonthEnd.Location = new System.Drawing.Point(92, 39);
            this.cbxDueAtMonthEnd.Name = "cbxDueAtMonthEnd";
            this.cbxDueAtMonthEnd.Size = new System.Drawing.Size(113, 17);
            this.cbxDueAtMonthEnd.TabIndex = 2;
            this.cbxDueAtMonthEnd.Text = "Due at Month End";
            this.cbxDueAtMonthEnd.UseVisualStyleBackColor = true;
            this.cbxDueAtMonthEnd.CheckedChanged += new System.EventHandler(this.cbxDueAtMonthEnd_CheckedChanged);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(403, 207);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(478, 207);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 15;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.lblTradeIn);
            this.groupBox1.Controls.Add(this.txtTradeIn);
            this.groupBox1.Location = new System.Drawing.Point(12, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 53);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // lblTradeIn
            // 
            this.lblTradeIn.AutoSize = true;
            this.lblTradeIn.Location = new System.Drawing.Point(54, 20);
            this.lblTradeIn.Name = "lblTradeIn";
            this.lblTradeIn.Size = new System.Drawing.Size(47, 13);
            this.lblTradeIn.TabIndex = 0;
            this.lblTradeIn.Text = "Trade In";
            // 
            // txtTradeIn
            // 
            this.txtTradeIn.Location = new System.Drawing.Point(102, 18);
            this.txtTradeIn.Name = "txtTradeIn";
            this.txtTradeIn.Size = new System.Drawing.Size(92, 20);
            this.txtTradeIn.TabIndex = 1;
            this.txtTradeIn.TextChanged += new System.EventHandler(this.txtTradeIn_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.btnSalePrice);
            this.groupBox2.Controls.Add(this.txtSalePrice);
            this.groupBox2.Controls.Add(this.lblSalePrice);
            this.groupBox2.Location = new System.Drawing.Point(288, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(270, 53);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // txtSalePrice
            // 
            this.txtSalePrice.Location = new System.Drawing.Point(102, 18);
            this.txtSalePrice.Name = "txtSalePrice";
            this.txtSalePrice.Size = new System.Drawing.Size(92, 20);
            this.txtSalePrice.TabIndex = 1;
            this.txtSalePrice.TextChanged += new System.EventHandler(this.txtSalePrice_TextChanged);
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.AutoSize = true;
            this.lblSalePrice.Location = new System.Drawing.Point(45, 21);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(55, 13);
            this.lblSalePrice.TabIndex = 0;
            this.lblSalePrice.Text = "Sale Price";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.txtDownPayment);
            this.groupBox3.Controls.Add(this.lblDownPayment);
            this.groupBox3.Location = new System.Drawing.Point(12, 63);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(270, 63);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            // 
            // txtDownPayment
            // 
            this.txtDownPayment.Location = new System.Drawing.Point(102, 22);
            this.txtDownPayment.Name = "txtDownPayment";
            this.txtDownPayment.Size = new System.Drawing.Size(92, 20);
            this.txtDownPayment.TabIndex = 1;
            this.txtDownPayment.TextChanged += new System.EventHandler(this.txtDownPayment_TextChanged);
            // 
            // lblDownPayment
            // 
            this.lblDownPayment.AutoSize = true;
            this.lblDownPayment.Location = new System.Drawing.Point(22, 26);
            this.lblDownPayment.Name = "lblDownPayment";
            this.lblDownPayment.Size = new System.Drawing.Size(79, 13);
            this.lblDownPayment.TabIndex = 0;
            this.lblDownPayment.Text = "Down Payment";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.cbxDueAtMonthEnd);
            this.groupBox4.Controls.Add(this.lblMonthlyPayment);
            this.groupBox4.Controls.Add(this.txtMonthlyPayment);
            this.groupBox4.Controls.Add(this.btnPayment);
            this.groupBox4.Location = new System.Drawing.Point(288, 63);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(270, 63);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            // 
            // lblMonthlyPayment
            // 
            this.lblMonthlyPayment.AutoSize = true;
            this.lblMonthlyPayment.Location = new System.Drawing.Point(12, 19);
            this.lblMonthlyPayment.Name = "lblMonthlyPayment";
            this.lblMonthlyPayment.Size = new System.Drawing.Size(88, 13);
            this.lblMonthlyPayment.TabIndex = 0;
            this.lblMonthlyPayment.Text = "Monthly Payment";
            // 
            // txtMonthlyPayment
            // 
            this.txtMonthlyPayment.Location = new System.Drawing.Point(102, 15);
            this.txtMonthlyPayment.Name = "txtMonthlyPayment";
            this.txtMonthlyPayment.Size = new System.Drawing.Size(92, 20);
            this.txtMonthlyPayment.TabIndex = 1;
            this.txtMonthlyPayment.TextChanged += new System.EventHandler(this.txtMonthlyPayment_TextChanged);
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(198, 14);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(66, 23);
            this.btnPayment.TabIndex = 0;
            this.btnPayment.Text = "Calculate";
            this.btnPayment.UseVisualStyleBackColor = true;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblCompensatingBalance);
            this.groupBox5.Controls.Add(this.lblLoanPresentValue);
            this.groupBox5.Controls.Add(this.txtPresentValue);
            this.groupBox5.Controls.Add(this.txtCompensatingBalance);
            this.groupBox5.Location = new System.Drawing.Point(12, 126);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(270, 73);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            // 
            // lblCompensatingBalance
            // 
            this.lblCompensatingBalance.AutoSize = true;
            this.lblCompensatingBalance.Location = new System.Drawing.Point(20, 19);
            this.lblCompensatingBalance.Name = "lblCompensatingBalance";
            this.lblCompensatingBalance.Size = new System.Drawing.Size(116, 13);
            this.lblCompensatingBalance.TabIndex = 0;
            this.lblCompensatingBalance.Text = "Compensating Balance";
            // 
            // txtCompensatingBalance
            // 
            this.txtCompensatingBalance.BackColor = System.Drawing.SystemColors.Control;
            this.txtCompensatingBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCompensatingBalance.Location = new System.Drawing.Point(136, 19);
            this.txtCompensatingBalance.Name = "txtCompensatingBalance";
            this.txtCompensatingBalance.ReadOnly = true;
            this.txtCompensatingBalance.Size = new System.Drawing.Size(92, 13);
            this.txtCompensatingBalance.TabIndex = 1;
            this.txtCompensatingBalance.TabStop = false;
            // 
            // btnInterest
            // 
            this.btnInterest.Location = new System.Drawing.Point(198, 44);
            this.btnInterest.Name = "btnInterest";
            this.btnInterest.Size = new System.Drawing.Size(66, 23);
            this.btnInterest.TabIndex = 4;
            this.btnInterest.Text = "Calculate";
            this.btnInterest.UseVisualStyleBackColor = true;
            this.btnInterest.Click += new System.EventHandler(this.btnInterest_Click);
            // 
            // btnNumPayments
            // 
            this.btnNumPayments.Location = new System.Drawing.Point(198, 14);
            this.btnNumPayments.Name = "btnNumPayments";
            this.btnNumPayments.Size = new System.Drawing.Size(66, 23);
            this.btnNumPayments.TabIndex = 5;
            this.btnNumPayments.Text = "Calculate";
            this.btnNumPayments.UseVisualStyleBackColor = true;
            this.btnNumPayments.Click += new System.EventHandler(this.btnNumPayments_Click);
            // 
            // lblNumPayments
            // 
            this.lblNumPayments.AutoSize = true;
            this.lblNumPayments.Location = new System.Drawing.Point(37, 19);
            this.lblNumPayments.Name = "lblNumPayments";
            this.lblNumPayments.Size = new System.Drawing.Size(63, 13);
            this.lblNumPayments.TabIndex = 0;
            this.lblNumPayments.Text = "# Payments";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnInterest);
            this.groupBox6.Controls.Add(this.btnNumPayments);
            this.groupBox6.Controls.Add(this.txtInterestRate);
            this.groupBox6.Controls.Add(this.lblNumPayments);
            this.groupBox6.Controls.Add(this.txtNumberPayments);
            this.groupBox6.Controls.Add(this.lblInterestRate);
            this.groupBox6.Location = new System.Drawing.Point(288, 126);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(269, 73);
            this.groupBox6.TabIndex = 13;
            this.groupBox6.TabStop = false;
            // 
            // txtNumberPayments
            // 
            this.txtNumberPayments.Location = new System.Drawing.Point(102, 15);
            this.txtNumberPayments.Name = "txtNumberPayments";
            this.txtNumberPayments.Size = new System.Drawing.Size(92, 20);
            this.txtNumberPayments.TabIndex = 1;
            this.txtNumberPayments.TextChanged += new System.EventHandler(this.txtNumberPayments_TextChanged);
            // 
            // frmLoanWorksheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 241);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox6);
            this.Name = "frmLoanWorksheet";
            this.Text = "Car Loan Worksheet";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSalePrice;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.Label lblInterestRate;
        private System.Windows.Forms.Label lblLoanPresentValue;
        private System.Windows.Forms.TextBox txtPresentValue;
        private System.Windows.Forms.CheckBox cbxDueAtMonthEnd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblTradeIn;
        private System.Windows.Forms.TextBox txtTradeIn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSalePrice;
        private System.Windows.Forms.Label lblSalePrice;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtDownPayment;
        private System.Windows.Forms.Label lblDownPayment;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblMonthlyPayment;
        private System.Windows.Forms.TextBox txtMonthlyPayment;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblCompensatingBalance;
        private System.Windows.Forms.TextBox txtCompensatingBalance;
        private System.Windows.Forms.Button btnInterest;
        private System.Windows.Forms.Button btnNumPayments;
        private System.Windows.Forms.Label lblNumPayments;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox txtNumberPayments;
    }
}