﻿namespace LoanCalculator
{
    partial class frmLoanWorksheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDone = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.cbxDueAtMonthEnd = new System.Windows.Forms.CheckBox();
            this.txtMonthlyPayment = new System.Windows.Forms.TextBox();
            this.btnInterest = new System.Windows.Forms.Button();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.btnNumPayments = new System.Windows.Forms.Button();
            this.txtNumberPayments = new System.Windows.Forms.TextBox();
            this.btnSalePrice = new System.Windows.Forms.Button();
            this.txtSalePrice = new System.Windows.Forms.TextBox();
            this.txtDownPayment = new System.Windows.Forms.TextBox();
            this.txtAmountStillOwed = new System.Windows.Forms.TextBox();
            this.txtTradeIn = new System.Windows.Forms.TextBox();
            this.lblTradeIn = new System.Windows.Forms.Label();
            this.lblDownPayment = new System.Windows.Forms.Label();
            this.lblAmtOwed = new System.Windows.Forms.Label();
            this.txtCompensatingBalance = new System.Windows.Forms.TextBox();
            this.lblLoanPresentValue = new System.Windows.Forms.Label();
            this.lblCompensatingBalance = new System.Windows.Forms.Label();
            this.lblSalePrice = new System.Windows.Forms.Label();
            this.txtPresentValue = new System.Windows.Forms.TextBox();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.lblNumPayments = new System.Windows.Forms.Label();
            this.lblMonthlyPayment = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(220, 278);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 14;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(145, 278);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.Location = new System.Drawing.Point(229, 228);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(66, 23);
            this.btnPayment.TabIndex = 12;
            this.btnPayment.Text = "Calculate";
            this.btnPayment.UseVisualStyleBackColor = true;
            // 
            // cbxDueAtMonthEnd
            // 
            this.cbxDueAtMonthEnd.AutoSize = true;
            this.cbxDueAtMonthEnd.Location = new System.Drawing.Point(131, 256);
            this.cbxDueAtMonthEnd.Name = "cbxDueAtMonthEnd";
            this.cbxDueAtMonthEnd.Size = new System.Drawing.Size(113, 17);
            this.cbxDueAtMonthEnd.TabIndex = 11;
            this.cbxDueAtMonthEnd.Text = "Due at Month End";
            this.cbxDueAtMonthEnd.UseVisualStyleBackColor = true;
            // 
            // txtMonthlyPayment
            // 
            this.txtMonthlyPayment.Location = new System.Drawing.Point(131, 230);
            this.txtMonthlyPayment.Name = "txtMonthlyPayment";
            this.txtMonthlyPayment.Size = new System.Drawing.Size(92, 20);
            this.txtMonthlyPayment.TabIndex = 10;
            // 
            // btnInterest
            // 
            this.btnInterest.Location = new System.Drawing.Point(229, 199);
            this.btnInterest.Name = "btnInterest";
            this.btnInterest.Size = new System.Drawing.Size(66, 23);
            this.btnInterest.TabIndex = 9;
            this.btnInterest.Text = "Calculate";
            this.btnInterest.UseVisualStyleBackColor = true;
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Location = new System.Drawing.Point(131, 201);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(92, 20);
            this.txtInterestRate.TabIndex = 8;
            // 
            // btnNumPayments
            // 
            this.btnNumPayments.Location = new System.Drawing.Point(229, 170);
            this.btnNumPayments.Name = "btnNumPayments";
            this.btnNumPayments.Size = new System.Drawing.Size(66, 23);
            this.btnNumPayments.TabIndex = 7;
            this.btnNumPayments.Text = "Calculate";
            this.btnNumPayments.UseVisualStyleBackColor = true;
            // 
            // txtNumberPayments
            // 
            this.txtNumberPayments.Location = new System.Drawing.Point(131, 172);
            this.txtNumberPayments.Name = "txtNumberPayments";
            this.txtNumberPayments.Size = new System.Drawing.Size(92, 20);
            this.txtNumberPayments.TabIndex = 6;
            // 
            // btnSalePrice
            // 
            this.btnSalePrice.Location = new System.Drawing.Point(229, 119);
            this.btnSalePrice.Name = "btnSalePrice";
            this.btnSalePrice.Size = new System.Drawing.Size(66, 23);
            this.btnSalePrice.TabIndex = 5;
            this.btnSalePrice.Text = "Calculate";
            this.btnSalePrice.UseVisualStyleBackColor = true;
            // 
            // txtSalePrice
            // 
            this.txtSalePrice.Location = new System.Drawing.Point(131, 121);
            this.txtSalePrice.Name = "txtSalePrice";
            this.txtSalePrice.Size = new System.Drawing.Size(92, 20);
            this.txtSalePrice.TabIndex = 4;
            // 
            // txtDownPayment
            // 
            this.txtDownPayment.Location = new System.Drawing.Point(131, 70);
            this.txtDownPayment.Name = "txtDownPayment";
            this.txtDownPayment.Size = new System.Drawing.Size(92, 20);
            this.txtDownPayment.TabIndex = 3;
            // 
            // txtAmountStillOwed
            // 
            this.txtAmountStillOwed.Location = new System.Drawing.Point(131, 41);
            this.txtAmountStillOwed.Name = "txtAmountStillOwed";
            this.txtAmountStillOwed.Size = new System.Drawing.Size(92, 20);
            this.txtAmountStillOwed.TabIndex = 2;
            this.txtAmountStillOwed.TextChanged += new System.EventHandler(this.txtAmountStillOwed_TextChanged);
            // 
            // txtTradeIn
            // 
            this.txtTradeIn.Location = new System.Drawing.Point(131, 12);
            this.txtTradeIn.Name = "txtTradeIn";
            this.txtTradeIn.Size = new System.Drawing.Size(92, 20);
            this.txtTradeIn.TabIndex = 1;
            // 
            // lblTradeIn
            // 
            this.lblTradeIn.AutoSize = true;
            this.lblTradeIn.Location = new System.Drawing.Point(78, 15);
            this.lblTradeIn.Name = "lblTradeIn";
            this.lblTradeIn.Size = new System.Drawing.Size(47, 13);
            this.lblTradeIn.TabIndex = 28;
            this.lblTradeIn.Text = "Trade-In";
            this.lblTradeIn.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblDownPayment
            // 
            this.lblDownPayment.AutoSize = true;
            this.lblDownPayment.Location = new System.Drawing.Point(46, 73);
            this.lblDownPayment.Name = "lblDownPayment";
            this.lblDownPayment.Size = new System.Drawing.Size(79, 13);
            this.lblDownPayment.TabIndex = 33;
            this.lblDownPayment.Text = "Down Payment";
            this.lblDownPayment.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAmtOwed
            // 
            this.lblAmtOwed.AutoSize = true;
            this.lblAmtOwed.Location = new System.Drawing.Point(32, 44);
            this.lblAmtOwed.Name = "lblAmtOwed";
            this.lblAmtOwed.Size = new System.Drawing.Size(93, 13);
            this.lblAmtOwed.TabIndex = 37;
            this.lblAmtOwed.Text = "Amount Still Owed";
            this.lblAmtOwed.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtCompensatingBalance
            // 
            this.txtCompensatingBalance.BackColor = System.Drawing.SystemColors.Control;
            this.txtCompensatingBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCompensatingBalance.Location = new System.Drawing.Point(131, 99);
            this.txtCompensatingBalance.Name = "txtCompensatingBalance";
            this.txtCompensatingBalance.ReadOnly = true;
            this.txtCompensatingBalance.Size = new System.Drawing.Size(92, 13);
            this.txtCompensatingBalance.TabIndex = 31;
            this.txtCompensatingBalance.TabStop = false;
            // 
            // lblLoanPresentValue
            // 
            this.lblLoanPresentValue.AutoSize = true;
            this.lblLoanPresentValue.Location = new System.Drawing.Point(35, 150);
            this.lblLoanPresentValue.Name = "lblLoanPresentValue";
            this.lblLoanPresentValue.Size = new System.Drawing.Size(90, 13);
            this.lblLoanPresentValue.TabIndex = 34;
            this.lblLoanPresentValue.Text = "Amount Financed";
            // 
            // lblCompensatingBalance
            // 
            this.lblCompensatingBalance.AutoSize = true;
            this.lblCompensatingBalance.Location = new System.Drawing.Point(9, 99);
            this.lblCompensatingBalance.Name = "lblCompensatingBalance";
            this.lblCompensatingBalance.Size = new System.Drawing.Size(116, 13);
            this.lblCompensatingBalance.TabIndex = 26;
            this.lblCompensatingBalance.Text = "Compensating Balance";
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.AutoSize = true;
            this.lblSalePrice.Location = new System.Drawing.Point(70, 124);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(55, 13);
            this.lblSalePrice.TabIndex = 27;
            this.lblSalePrice.Text = "Sale Price";
            // 
            // txtPresentValue
            // 
            this.txtPresentValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPresentValue.Location = new System.Drawing.Point(131, 150);
            this.txtPresentValue.Name = "txtPresentValue";
            this.txtPresentValue.ReadOnly = true;
            this.txtPresentValue.Size = new System.Drawing.Size(92, 13);
            this.txtPresentValue.TabIndex = 36;
            this.txtPresentValue.TabStop = false;
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Location = new System.Drawing.Point(88, 204);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(37, 13);
            this.lblInterestRate.TabIndex = 41;
            this.lblInterestRate.Text = "APR%";
            // 
            // lblNumPayments
            // 
            this.lblNumPayments.AutoSize = true;
            this.lblNumPayments.Location = new System.Drawing.Point(62, 175);
            this.lblNumPayments.Name = "lblNumPayments";
            this.lblNumPayments.Size = new System.Drawing.Size(63, 13);
            this.lblNumPayments.TabIndex = 39;
            this.lblNumPayments.Text = "# Payments";
            // 
            // lblMonthlyPayment
            // 
            this.lblMonthlyPayment.AutoSize = true;
            this.lblMonthlyPayment.Location = new System.Drawing.Point(37, 233);
            this.lblMonthlyPayment.Name = "lblMonthlyPayment";
            this.lblMonthlyPayment.Size = new System.Drawing.Size(88, 13);
            this.lblMonthlyPayment.TabIndex = 45;
            this.lblMonthlyPayment.Text = "Monthly Payment";
            // 
            // frmLoanWorksheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 308);
            this.Controls.Add(this.lblMonthlyPayment);
            this.Controls.Add(this.lblNumPayments);
            this.Controls.Add(this.lblInterestRate);
            this.Controls.Add(this.txtPresentValue);
            this.Controls.Add(this.lblSalePrice);
            this.Controls.Add(this.lblCompensatingBalance);
            this.Controls.Add(this.lblLoanPresentValue);
            this.Controls.Add(this.txtCompensatingBalance);
            this.Controls.Add(this.lblAmtOwed);
            this.Controls.Add(this.lblDownPayment);
            this.Controls.Add(this.lblTradeIn);
            this.Controls.Add(this.txtTradeIn);
            this.Controls.Add(this.txtAmountStillOwed);
            this.Controls.Add(this.txtDownPayment);
            this.Controls.Add(this.txtSalePrice);
            this.Controls.Add(this.btnSalePrice);
            this.Controls.Add(this.txtNumberPayments);
            this.Controls.Add(this.btnNumPayments);
            this.Controls.Add(this.txtInterestRate);
            this.Controls.Add(this.btnInterest);
            this.Controls.Add(this.txtMonthlyPayment);
            this.Controls.Add(this.cbxDueAtMonthEnd);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDone);
            this.Name = "frmLoanWorksheet";
            this.Text = "Car Loan Worksheet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDone;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.CheckBox cbxDueAtMonthEnd;
        private System.Windows.Forms.TextBox txtMonthlyPayment;
        private System.Windows.Forms.Button btnInterest;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.Button btnNumPayments;
        private System.Windows.Forms.TextBox txtNumberPayments;
        private System.Windows.Forms.Button btnSalePrice;
        private System.Windows.Forms.TextBox txtSalePrice;
        private System.Windows.Forms.TextBox txtDownPayment;
        private System.Windows.Forms.TextBox txtAmountStillOwed;
        private System.Windows.Forms.TextBox txtTradeIn;
        private System.Windows.Forms.Label lblTradeIn;
        private System.Windows.Forms.Label lblDownPayment;
        private System.Windows.Forms.Label lblAmtOwed;
        private System.Windows.Forms.TextBox txtCompensatingBalance;
        private System.Windows.Forms.Label lblLoanPresentValue;
        private System.Windows.Forms.Label lblCompensatingBalance;
        private System.Windows.Forms.Label lblSalePrice;
        private System.Windows.Forms.TextBox txtPresentValue;
        private System.Windows.Forms.Label lblInterestRate;
        private System.Windows.Forms.Label lblNumPayments;
        private System.Windows.Forms.Label lblMonthlyPayment;
    }
}